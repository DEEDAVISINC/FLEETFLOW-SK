Imports System
Imports System.Xml
Imports System.Xml.XPath
Imports System.IO
Imports System.Text
Imports CompressionExtensionClient.SoapCompression.WebServices

Public Class Form1
    Inherits System.Windows.Forms.Form
    'The folder "c:\CompressionExtensionFiles\" must be created and the
    'ASPNET user must have permission to write to the folder
    'so that the soap envelopes can be written to disk for inspection.

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()
        Application.EnableVisualStyles()
        Application.DoEvents()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents btnOpen As System.Windows.Forms.Button
    Friend WithEvents txtOpen As System.Windows.Forms.TextBox
    Friend WithEvents btnSubmit As System.Windows.Forms.Button
    Friend WithEvents txtReturn As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtToken As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.btnOpen = New System.Windows.Forms.Button
        Me.txtOpen = New System.Windows.Forms.TextBox
        Me.btnSubmit = New System.Windows.Forms.Button
        Me.txtReturn = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtToken = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'OpenFileDialog1
        '
        '
        'btnOpen
        '
        Me.btnOpen.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnOpen.Location = New System.Drawing.Point(136, 64)
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.TabIndex = 5
        Me.btnOpen.Text = "Open"
        '
        'txtOpen
        '
        Me.txtOpen.Location = New System.Drawing.Point(128, 112)
        Me.txtOpen.Name = "txtOpen"
        Me.txtOpen.Size = New System.Drawing.Size(264, 20)
        Me.txtOpen.TabIndex = 6
        Me.txtOpen.Text = ""
        '
        'btnSubmit
        '
        Me.btnSubmit.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnSubmit.Location = New System.Drawing.Point(232, 64)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.TabIndex = 7
        Me.btnSubmit.Text = "Submit"
        '
        'txtReturn
        '
        Me.txtReturn.Location = New System.Drawing.Point(128, 152)
        Me.txtReturn.Name = "txtReturn"
        Me.txtReturn.Size = New System.Drawing.Size(264, 20)
        Me.txtReturn.TabIndex = 8
        Me.txtReturn.Text = ""
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtToken)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtOpen)
        Me.GroupBox1.Controls.Add(Me.btnOpen)
        Me.GroupBox1.Controls.Add(Me.txtReturn)
        Me.GroupBox1.Controls.Add(Me.btnSubmit)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.GroupBox1.Location = New System.Drawing.Point(40, 16)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(424, 200)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Submit to MQ Training Queue"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Arial", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(40, 32)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 16)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Token Value"
        '
        'txtToken
        '
        Me.txtToken.Location = New System.Drawing.Point(128, 32)
        Me.txtToken.Name = "txtToken"
        Me.txtToken.Size = New System.Drawing.Size(264, 20)
        Me.txtToken.TabIndex = 11
        Me.txtToken.Text = ""
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(40, 152)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 16)
        Me.Label2.TabIndex = 10
        Me.Label2.Text = "Return String"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Arial", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(80, 112)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 16)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "File"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(488, 246)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        txtOpen.Text = Me.OpenFileDialog1.FileName
    End Sub

    Public Function callWebService()
        Dim ReturnString As String

        '1) Create NOADWebService dll via the Visual Studio .Net Command Prompt via following steps:
        '2) From VS command prompt:  wsdl /l:VB https://testnoad.nvmc.uscg.gov/noadwebservice/noadwebservice.asmx?wsdl
        '3) Open NOADWebService.vb in notepad and modify URL to: https://testnoad.nvmc.uscg.gov/noadwebservice/noadwebservice.asmx
        '4) In VS command prompt:   vbc /t:library /r:System.XML.dll,System.Web.Services.dll,System.Data.dll,System.Web.dll,System.dll,SharpZipLib.dll,CompressionExtensionClient.dll NOADWebService.vb
        '5) See following knowledge base article for more details:  http://support.microsoft.com/kb/815213

        Dim devRef As New NOADWebService

        'set soapheader token value
        devRef.sHeaderValue = New sHeader

        'Add Your Token value here
        devRef.sHeaderValue.Token = Me.txtToken.Text

        Dim XmlDoc As XmlDataDocument = New XmlDataDocument

        XmlDoc.Load(Me.txtOpen.Text)
        'Call Compressed Method
        ReturnString = devRef.noadSubmitCompressed(XmlDoc.OuterXml)

        'Call NonCompressed Method
        'ReturnString = devRef.noadSubmit(XmlDoc.OuterXml)

        Me.txtReturn.Text = ReturnString
    End Function

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        callWebService()
    End Sub

    Private Sub btnOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpen.Click
        Me.OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub
End Class
