Imports System
Imports System.Xml
Imports System.Xml.XPath
Imports System.IO
Imports System.Text

Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents txtOpen As System.Windows.Forms.Button
    Friend WithEvents txtSubmit As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents txtToken As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.txtOpen = New System.Windows.Forms.Button
        Me.txtSubmit = New System.Windows.Forms.Button
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog
        Me.txtToken = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(136, 120)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(256, 20)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = ""
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(136, 152)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(256, 20)
        Me.TextBox2.TabIndex = 1
        Me.TextBox2.Text = ""
        '
        'txtOpen
        '
        Me.txtOpen.Location = New System.Drawing.Point(152, 88)
        Me.txtOpen.Name = "txtOpen"
        Me.txtOpen.TabIndex = 2
        Me.txtOpen.Text = "Open"
        '
        'txtSubmit
        '
        Me.txtSubmit.Location = New System.Drawing.Point(240, 88)
        Me.txtSubmit.Name = "txtSubmit"
        Me.txtSubmit.TabIndex = 3
        Me.txtSubmit.Text = "Submit"
        '
        'OpenFileDialog1
        '
        '
        'txtToken
        '
        Me.txtToken.Location = New System.Drawing.Point(136, 56)
        Me.txtToken.Name = "txtToken"
        Me.txtToken.Size = New System.Drawing.Size(256, 20)
        Me.txtToken.TabIndex = 4
        Me.txtToken.Text = ""
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(32, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 16)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Add Token Here:"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(80, 120)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 16)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Open:"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(40, 152)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 16)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Return String:"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(32, 32)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(336, 16)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Get your token from the NVMC Web Site Devlopers page."
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(432, 230)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtToken)
        Me.Controls.Add(Me.txtSubmit)
        Me.Controls.Add(Me.txtOpen)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub OpenFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles OpenFileDialog1.FileOk
        Me.TextBox1.Text = Me.OpenFileDialog1.FileName
    End Sub

    Private Sub txtOpen_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtOpen.Click
        Me.OpenFileDialog1.ShowDialog()
    End Sub

    Private Sub txtSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSubmit.Click
        Dim ReturnString As String

        '1) Create NOADWebService dll via the Visual Studio .Net Command Prompt via following steps:
        '2) From VS command prompt:  wsdl /l:VB https://testnoad.nvmc.uscg.gov/noadwebservice/noadwebservice.asmx?wsdl
        '3) Open NOADWebService.vb in notepad and modify URL to: https://testnoad.nvmc.uscg.gov/noadwebservice/noadwebservice.asmx
        '4) In VS command prompt:   vbc /t:library /r:System.XML.dll,System.Web.Services.dll,System.Data.dll,System.Web.dll,System.dll NOADWebService.vb
        '5) See following knowledge base article for more details:  http://support.microsoft.com/kb/815213

        'NOADWebService reference
        Dim devRef As New NOADWebService

        'set soapheader token value
        devRef.sHeaderValue = New sHeader
        'Add Your Token value here
        devRef.sHeaderValue.Token = Me.txtToken.Text

        Dim XmlDoc As XmlDataDocument = New XmlDataDocument

        XmlDoc.Load(Me.TextBox1.Text)
        'Call NonCompressed Method
        ReturnString = devRef.noadSubmit(XmlDoc.OuterXml)

        Me.TextBox2.Text = ReturnString
    End Sub
End Class
